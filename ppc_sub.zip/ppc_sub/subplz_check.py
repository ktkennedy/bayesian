import rospy
import message_filters
from geometry_msgs.msg import PoseStamped
from nav_msgs.msg import Odometry
from ackermann_msgs.msg import AckermannDriveStamped
from scipy.interpolate import interp1d
from scipy.spatial.distance import pdist, squareform
import numpy as np
import matplotlib.pyplot as plt
import threading
import time
import os

class DataCollector:
    def __init__(self, initial_wait_time=5, position_tolerance=0.5):
        self.output_path = ''
        self.collected_data = []
        self.stop_flag = False
        self.last_speed = None
        self.last_time = None
        self.latest_ackermann_msg = None
        self.latest_odom_msg = None
        self.start_position = None
        self.position_tolerance = position_tolerance
        self.start_time = None
        self.initial_wait_time = initial_wait_time
        self.file_counter = 0
        self.Start = False
        self.previous_time = None
        self.time_change = 0
    def calculate_acceleration(self, current_speed, current_time):
        if self.last_speed is None or self.last_time is None:
            self.last_speed = current_speed
            self.last_time = current_time
            return 0.01
        dt = 0.05
        if dt <= 0:
            return 0.01
        acceleration = (current_speed - self.last_speed) / dt

        self.last_speed = current_speed
        self.last_time = current_time

        return acceleration

    def ackermann_callback(self, data):
        self.latest_ackermann_msg = data

    def odom_callback(self, data):
        self.latest_odom_msg = data
        self.process_data()

    def process_data(self):
        if not self.Start or self.latest_ackermann_msg is None or self.latest_odom_msg is None:
            return  # Do not process if either message is missing

        # Extract data from messages
        steering_angle = self.latest_ackermann_msg.drive.steering_angle
        x_position = self.latest_odom_msg.pose.pose.position.x
        y_position = self.latest_odom_msg.pose.pose.position.y
        current_position = (x_position, y_position)
        psi = self.latest_odom_msg.pose.pose.orientation.w
        speed = self.latest_odom_msg.twist.twist.linear.x
        current_time = self.latest_odom_msg.header.stamp.to_sec()
        if self.previous_time is not None:
            self.time_change +=current_time - self.previous_time
        
        self.previous_time = current_time

        acceleration = self.calculate_acceleration(speed, current_time)

        # Append data to the collected data list
        self.collected_data.append((x_position, y_position, psi, speed, acceleration, steering_angle,self.time_change))

        # Initial setup for start position and start time
        if self.start_time is None:
            self.start_time = time.time()
            self.start_position = current_position
            print('Start', self.start_position)
            return

        # Check for the initial wait time before starting data collection
        if time.time() - self.start_time < self.initial_wait_time:
            return

        # Check if the current position is close enough to the start position to consider a lap complete
        if np.linalg.norm(np.array(current_position) - np.array(self.start_position)) < self.position_tolerance:
            print('Distance from start:', np.linalg.norm(np.array(current_position) - np.array(self.start_position)))
            self.output_path = self.create_output_path('/home/kennedy/research/ppc_track/result', 'optimized_traj')
            print('Saving data to:', self.output_path)

            self.save_data_to_file()

            # Reset for the next lap
            self.collected_data = []
            self.start_position = None
            self.start_time = None
            self.file_counter += 1
            self.output_path = self.create_output_path('/home/kennedy/research/ppc_track/result', 'optimized_traj')
            self.previous_time = None
            self.time_change = 0
            print('New lap started, data will be saved to:', self.output_path)

    def create_output_path(self, base_path, base_filename):
        new_filename = f"{base_filename}{self.file_counter}.txt"
        return os.path.join(base_path, new_filename)

    def save_data_to_file(self):
        if not self.collected_data:
            return

        data = np.array(self.collected_data)
        x = np.array(self.collected_data)[:,0]
        y = np.array(self.collected_data)[:,1]
        z = np.array(self.collected_data)[:,2]
        a = np.array(self.collected_data)[:,3]
        b = np.array(self.collected_data)[:,4]
        c = np.array(self.collected_data)[:,5]
        d = np.array(self.collected_data)[:,6]
        interp_func_x = interp1d(np.arange(len(x)), x, bounds_error=False, fill_value="extrapolate")
        interp_func_y = interp1d(np.arange(len(x)), y, bounds_error=False, fill_value="extrapolate")
        interp_func_z = interp1d(np.arange(len(x)), z, bounds_error=False, fill_value="extrapolate")
        interp_func_a = interp1d(np.arange(len(x)), a, bounds_error=False, fill_value="extrapolate")
        interp_func_b = interp1d(np.arange(len(x)), b, bounds_error=False, fill_value="extrapolate")
        interp_func_c = interp1d(np.arange(len(x)), c, bounds_error=False, fill_value="extrapolate")
        interp_func_d = interp1d(np.arange(len(x)), d, bounds_error=False, fill_value="extrapolate")

        index_new = np.linspace(0, len(x)-1, len(self.data))
    
        x_new = interp_func_x(index_new)
        y_new = interp_func_y(index_new)
        z_new = interp_func_z(index_new)
        a_new = interp_func_a(index_new)
        b_new = interp_func_b(index_new)
        c_new = interp_func_c(index_new)
        d_new = interp_func_d(index_new)

        new_data = np.column_stack((x_new, y_new,z_new,a_new,b_new,c_new,d_new))
        collected_data = new_data
        np.savetxt(self.output_path, collected_data, delimiter = ",", fmt='%f')

    def check_user_input(self):
        user_input = input("Enter 'stop' to stop data collection: ")
        if user_input.strip().lower() == 'stop':
            self.stop_flag = True
            rospy.signal_shutdown("User requested shutdown")

    def listener(self):
        rospy.init_node('pose_xy_listener', anonymous=True)
        input_thread = threading.Thread(target=self.check_user_input)
        input_thread.start()
        rospy.Subscriber("/car_state/odom", Odometry, self.odom_callback)
        rospy.Subscriber("/vesc/high_level/ackermann_cmd_mux/input/nav_1", AckermannDriveStamped, self.ackermann_callback)
        self.data = np.loadtxt("/home/kennedy/f1tenth_ws/src/MAP-Controller/F110_ROS_Simulator/maps/u/optimized_traj.txt", delimiter=",", dtype=float)
        x= self.data[0,0]
        y=self.data[0,1]
        rate = rospy.Rate(20)
        while not rospy.is_shutdown() and not self.stop_flag:
            if self.latest_odom_msg is not None:
                x_current = self.latest_odom_msg.pose.pose.position.x
                y_current = self.latest_odom_msg.pose.pose.position.y
                distance = np.linalg.norm([x_current - x, + y_current - y])
                if not self.Start and distance < 1:
                    self.Start = True
                    print("starting data recording")
            if self.Start:
                self.process_data()
            rate.sleep()

        self.save_data_to_file()
    
    # def calculate_ey_and_normalize(self):
    #     # Load ey_real data
    #     ey_real = np.loadtxt(self.output_path, delimiter=",", dtype=float)

    #     # Load ey_desire data
    #     ey_desire = np.loadtxt("/home/kennedy/f1tenth_ws/src/MAP-Controller/F110_ROS_Simulator/maps/u/optimized_traj.txt", delimiter=",", dtype=float)

    #     # Ensure both datasets have the same length
    #     interp_func_real = interp1d(np.arange(len(ey_real)), ey_real, axis=0)
    #     interp_func_desire = interp1d(np.arange(len(ey_desire)), ey_desire, axis=0)

    #     index_new = np.linspace(0, len(ey_real)-1, len(ey_desire))

    #     ey_real_new = interp_func_real(index_new)
    #     ey_desire_new = interp_func_desire(index_new)

    #     # Calculate ey for each index
    #     ey = np.linalg.norm(ey_real_new[:, :2] - ey_desire_new[:, :2], axis=1)

    #     # Normalize ey values to be between 0 and 1
    #     ey_normalized = (ey - np.min(ey)) / (np.max(ey) - np.min(ey))

    #     # Save the normalized ey values
    #     np.savetxt("ey_normalized.txt", ey_normalized, fmt='%f')

    #     return ey_normalized

if __name__ == '__main__':
    data_collector = DataCollector()
    data_collector.listener()
